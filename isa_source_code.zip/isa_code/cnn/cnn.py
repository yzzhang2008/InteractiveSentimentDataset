#coding=utf8
from __future__ import division
import numpy as np
import pandas as pd
import cPickle as Pickle
import os, time, sys
from sklearn.utils import shuffle
from sklearn import linear_model, metrics
from os.path import join as Join


import theano
import theano.tensor as T
import theano.tensor.shared_randomstreams
from theano.tensor.signal import downsample

from nnlayer import HiddenLayer, LogisticRegression, CNNLayer
from util import batch_num, share_x, share_y, sentence_indece




if __name__ == '__main__':
	# ccv=2

	itera_number = 80
	batch_size = 60
	step = 3
	filter_num = 50
	learning_rate = 0.01

	senlen = 20

	classnum = 3
	channel_num = 1

	rng = np.random.RandomState(23455)
	datas = Pickle.load(open("all_datas.p","rb"))
	# print(datas)
	# exit()
	labels = Pickle.load(open("all_label.p","rb"))
	alphabet = Pickle.load(open(Join('interdata', 'alphabet'), 'rb'))
	
	for ccv in range(0,10):

		
		test = datas[datas['cv'] == ccv]
		train = datas[datas['cv'] != ccv]

		

		train_sens, train_labels = sentence_indece(train, senlen, alphabet)
		test_sens, test_labels = sentence_indece(test, senlen, alphabet)

		train_sens = share_x(train_sens, batch_size)
		train_labels = share_y(train_labels, batch_size)
		test_sens = share_x(test_sens, batch_size)
		test_labels = share_y(test_labels, batch_size)

		embeddings = Pickle.load(open(Join('interdata', 'vocab'), 'rb'))
		embedding_ndim = len(embeddings[0])

		train_sample_num = len(train)
		test_sample_num = len(test)
		train_batch_num = batch_num(train, batch_size)
		test_batch_num = batch_num(test, batch_size)
		
		image_shape = (batch_size, channel_num, senlen, embedding_ndim)
		filter_shape = (filter_num, channel_num, step, embedding_ndim)
		

		index = T.lscalar('index')
		x = T.matrix('x')
		y = T.ivector('y')

		Embeddings = theano.shared(value = embeddings, name = 'Embeddings', borrow=True)

		layer0 = Embeddings[T.cast(x.flatten(),dtype="int32")].\
		reshape((batch_size, senlen, embedding_ndim))

		layer1 = CNNLayer(rng, input = layer0.reshape(image_shape), \
			filter_shape = filter_shape, image_shape = image_shape)

		layer2 = layer1.output.max(axis = 2).flatten(2)

		layer3 = LogisticRegression(layer2, filter_num, classnum)

		cost = layer3.negative_log_likelihood(y)

		params = layer1.params + layer3.params

		grads = T.grad(cost, params)
		updates = [(param_i, param_i - learning_rate * grad_i) for param_i, grad_i in zip(params, grads)]

		given_train = {x: train_sens[index * batch_size : (index + 1) * batch_size], \
			y: train_labels[index * batch_size : (index + 1) * batch_size]}

		given_test = {x: test_sens[index * batch_size : (index + 1) * batch_size], \
			y: test_labels[index * batch_size : (index + 1) * batch_size]}

		train_model = theano.function([index], cost, updates = updates, givens = given_train, on_unused_input='ignore', allow_input_downcast=True)
		train_model_pred = theano.function([index], layer3.y_pred, givens = given_train, on_unused_input='ignore', allow_input_downcast=True)
		test_model = theano.function([index], layer3.y_pred, givens = given_test, on_unused_input='ignore', allow_input_downcast=True)

		haha = theano.function([index], y, givens = given_train, on_unused_input='ignore', allow_input_downcast=True)


		print "begin to train"

		for itera_i in range(itera_number):
			print 'The ', itera_i, 'epcho begin'
			# print train_batch_num
			count_i = 0
			for i in range(train_batch_num):
				train_model(i)
				if count_i % 100 == 0:
					print count_i, 'batch train data have been trained'
				count_i += 1

			count_i = 0
			train_pred = []
			for i in range(train_batch_num):
				pred_label = train_model_pred(i)

				for j in pred_label:
					train_pred.append(j-1)
					# train_pred.append(j[1]+1)
				if count_i % 100 == 0:
					print count_i, 'batch train data have been pred'
				count_i += 1
			train_pred = train_pred[:train_sample_num]
			train_label = train['s_label']
			# print len(train_label)
			# print len(train_pred)
			# exit()

			# train_label = df_train['s_label']
			#不支持多分类
			# roc = metrics.roc_auc_score(train_label, train_pred)
			# print 'The roc of train is: ', roc*100
			acc = metrics.accuracy_score(train_label, train_pred)
			print 'The acc of train is: ', acc*100

		count_i = 0
		test_pred = []
		for i in range(test_batch_num):
			count_i +=1
			pred_label = test_model(i)
			for j in pred_label:
				test_pred.append(j-1)

			if count_i % 100 == 0:
					print count_i, 'batch test data have been pred '
		test_pred = test_pred[:test_sample_num]

		test_label = test['s_label']
		acc = metrics.accuracy_score(test_label, test_pred)
		print 'The acc of test is: ', acc*100
		filename = 'cnn_predicted_data'+str(ccv)+'.txt'
		np.savetxt(filename,test_pred,fmt='%d',newline='\n')





	# print test_pred




