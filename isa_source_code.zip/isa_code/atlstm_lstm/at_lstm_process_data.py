#coding=utf-8
import os,re
import numpy as np
import pandas as pd
import cPickle as Pickle
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer, HashingVectorizer, CountVectorizer
from sklearn import metrics
from sklearn.svm import SVC
from os.path import join as Join

from util import load_bin_vec, Alphabet, add_to_vocab



if __name__ == '__main__':
	
	rng = np.random.RandomState(23455)
	
	embeddings_file = Join('embeddings', 'aquaint+wiki.txt.gz.ndim=50.bin')#glove.6B.300d.txt
	know_dict = load_bin_vec(embeddings_file)
	ndim = len(know_dict[know_dict.keys()[0]])

	alphabet = Alphabet(start_feature_id=0)
	alphabet.add('UNKNOWN_WORD_IDX_0')

	content=pd.Series(open('content.txt','r').readlines())
	add_to_vocab(content, alphabet)
	print alphabet

	print alphabet.fid
	temp_vec = 0
	vocab_array = np.zeros((alphabet.fid, ndim), dtype = 'float32')
	word_2_vec=[]
	for index in alphabet.keys():
		# print index
		vec = know_dict.get(index, None)
		if vec is None:
			vec = rng.uniform(-0.25, 0.25, ndim)
			vec = list(vec)
			vec = np.array(vec, dtype = 'float32')
		if alphabet[index] == 0:
			vec = np.zeros(ndim)
		temp_vec += vec
		print alphabet[index]
		print index
		vocab_array[alphabet[index]] = vec
		# word_2_vec[alphabet[index]]=zip(index,vocab_array)
		print vocab_array[alphabet[index]]
	# alphabet = sorted(alphabet.items(),key = lambda item: item[1],reverse=True)
	wnv=[]
	for word, num ,vec in zip(alphabet.keys(),alphabet.values(),vocab_array):
	# for word, num in zip(alphabet[0],alphabet[1]):
		print word, num, vocab_array[alphabet[word]]
		wnv.append((word, num, vocab_array[alphabet[word]]))

	newwnv = sorted(wnv, key = lambda x:x[1])
	fwid=open('word_id.txt','w')
	feid=open('isa_word_embedding.txt','w')
	for i,j,k in newwnv:
		
		fwid.write(i)
		fwid.write(" ")
		fwid.write(str(j))
		fwid.write('\n')

		
		feid.write(i)
		feid.write(" ")
		k=str(k.tolist()).replace('[','')
		k=k.replace(']','')
		k=k.replace(',','')
		feid.write(k)
		feid.write('\n')
	fwid.close()
	feid.close()
	np.savetxt("filename.txt",newwnv[0],newwnv[2])
	
	