#coding=utf-8
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LinearRegression
from sklearn import metrics
import numpy as np
import pandas as pd
import cPickle
from collections import Counter
import re

for ccv in range(0,10):
	pre_list_str = ''
	oriname = 'epoch_9_test_pre_list_'+str(ccv)+'.txt'
	f= open(oriname,'r')
	for i in f.readlines():
		j = re.sub(r"[^str(0),str(1),str(2)]","",i)
		pre_list_str += j
	pre_list=[]
	for i in pre_list_str:
		if i=="0":
			j=-1
		elif i=="1":
			j=0
		else:
			j=1
		pre_list.append(j)
	filename = 'IAN_prelist_data'+str(ccv)+'.txt'
	np.savetxt(filename,pre_list,fmt='%d',newline='\n')
