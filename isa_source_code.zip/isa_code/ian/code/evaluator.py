#-*- coding:utf-8 -*-

import numpy as np
import tensorflow as tf

class Evaluator(object):
    """docstring for Evaluator"""
    def __init__(self, args, model):
        self.args = args
        self.model = model
        self.prediction = model.prediction


    def get_evaluation(self, sess, batches,dev_list=None):
        acc = 0
        n_examples = 0
        pre_list =[]
        for idx, batch in enumerate(batches):
            # print ('idx')
            # print (idx)
            # print (np.argmax(batch[2],1))
            
            feed_dict = {self.model.input_x : batch[0],
                         self.model.input_target : batch[1],
                         self.model.input_y : batch[2],
                         self.model.x_mask : batch[3],
                         self.model.target_mask : batch[4],
                         self.model.emb_mat: batch[5],
                         self.model.dropout_keep_prob : 1.0}
            prediction = sess.run(self.prediction, feed_dict=feed_dict)

            # print ('prediction')
            # print (prediction)
            pre_list.append(prediction)

            n_examples += len(batch[0])

            acc += np.sum(np.equal(prediction, np.argmax(batch[2],1)).astype('int'))

        acc = acc * 1.0 / n_examples
        return acc, pre_list
