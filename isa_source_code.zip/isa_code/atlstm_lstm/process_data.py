#coding=utf-8
import os,re
import numpy as np
import pandas as pd
import cPickle
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer, HashingVectorizer, CountVectorizer
from sklearn import metrics
from sklearn.svm import SVC

def getData(cv=10):
	datas = []
	labels =[]
	files= os.listdir("InteractiveSentimentDataset-v10") #得到文件夹下的所有文件名称
	np.random.RandomState(23455)  
		 
	for file in files: #遍历文件夹
		split = np.random.randint(0,cv)
		if not os.path.isdir(file):
			f = open("C:\Users\Ling\Desktop\interactdataset\experiment_SA\svm\InteractiveSentimentDataset-v10"+"\\"+file,'r')				
			lines = f.readlines()
			for line in lines[0:-2]:
				nline=line.strip().lower()
				# orig_line = clean_str(" ".join(nline))
				s_num,m,sen=nline.partition(":")
				sentence=sen[:-2].strip()
				# orig_sentence = clean_str(" ".join(sentence))
				

				sentence= re.sub(r"[, . ; \( \) \[ \] \' \"]", " ", sentence)
				sentence = re.sub(r"\?", " \? ", sentence)
				sentence=re.sub(r"\!", " \! ", sentence)
				sentence = re.sub(r"\s{2,}", " ", sentence)
				sentence =sentence.strip()


				# orig_sentence.split(" ")
				
				print s_num

				s_label=sen[-2:].strip()
				data={'name':file,
				  'cv':split,
				  'sentence_num':s_num,
				  'sentence':sentence,
				  's_label': int(s_label),
				  }

				# print s_num,s_label

				datas.append(data)



			a_label=lines[-1][:2].strip()
			b_label =lines[-1][-2:].strip()
			
			label={'name':file,
				  'cv':split,
				  'a_label': int(a_label),
				  'b_label': int(b_label),
				  }

			labels.append(label)
	return pd.DataFrame(datas), pd.DataFrame(labels)


datas, labels = getData(cv=10)
cPickle.dump(datas, open("all_datas.p", "w"))
cPickle.dump(labels, open("all_label.p", "w"))
print datas
print labels