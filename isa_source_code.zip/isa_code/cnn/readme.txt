三个文件夹
dataset里面是原数据集
embedings文件夹放的是词向量文件，用的词向量aquaint+wiki.txt.gz.ndim=50.bin
interdata文件夹放的是数据预处理后的生成文件

六个py文件
先运行process_data.py,生成两个pickle文件
再运行cnn.py,生成10折交叉验证的10个预测文件
然后运行cnn_add_result.py,生成直接加和的预测结果文件
最后运行cnn_lr_result.py,生成权重策略的预测结果文件