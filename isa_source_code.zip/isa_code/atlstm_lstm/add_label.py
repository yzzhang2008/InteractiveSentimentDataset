#coding =utf-8

f=open('aspect.txt','r')
f1=open('aspect_id.txt','w')
k=1
for i in f.readlines():
	f1.write(str(i).strip())
	f1.write(" "+str(k)+'\n')
	k+=1
f.close()
f1.close()

