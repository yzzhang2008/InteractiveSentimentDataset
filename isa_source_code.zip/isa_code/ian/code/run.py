 #-*- coding:utf-8 -*-
import os
import tensorflow as tf
from main import main as m

flags = tf.app.flags

# tf.flags.DEFINE_float("dev_sample_percentage", .1, "Percentage of the training data to use for validation"
flags.DEFINE_string("data_dir", "../data", "Data source dir.")
flags.DEFINE_string("out_dir", "../out", "Data source dir.")
flags.DEFINE_string("glove_file","../data/glove.6B.300d.txt","glove embedind")
# Model Hyperparameters
flags.DEFINE_integer("embedding_dim", 300, "Dimensionality of character embedding (default: 100)")
flags.DEFINE_integer("num_classes", 3, "Dimensionality of character embedding (default: 100)")
# tf.flags.DEFINE_integer("attention_size", 100, "Dimensionality of character attention (default: 100)")
flags.DEFINE_string("rnn_sizes", 300, "hidden units in rnn")
flags.DEFINE_integer("rnn_layers", 1, "Number of layers in IAN (default: 1)")
flags.DEFINE_float("dropout_keep_prob", 0.5, "Dropout keep probability (default: 0.5)")
flags.DEFINE_float("init_lr", 0.01, "Dropout keep probability (default: 0.5)")
flags.DEFINE_float("l2_reg_lambda", 0.00002, "L2 regularization lambda (default: 0.0)")

# Training parameters
flags.DEFINE_integer("batch_size", 60, "Batch Size (default: 64)")
flags.DEFINE_integer("num_epoches", 10, "Number of training epochs (default: 50)")#yuanshi shi 200
flags.DEFINE_integer("eval_iter", 50, "Evaluate model on dev set after this many steps (default: 100)")
flags.DEFINE_integer("checkpoint_every", 100, "Save model after this many steps (default: 100)")
flags.DEFINE_integer("num_checkpoints", 5, "Number of checkpoints to store (default: 5)")
# Misc Parameters
flags.DEFINE_boolean("allow_soft_placement", True, "Allow device soft device placement")
flags.DEFINE_boolean("log_device_placement", False, "Log placement of ops on devices")
flags.DEFINE_boolean("load",False,"load")

FLAGS = tf.flags.FLAGS

def main(_):
    args = flags.FLAGS

    m(args)

if __name__ == "__main__":
    tf.app.run()
