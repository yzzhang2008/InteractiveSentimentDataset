import tensorflow as tf
import numpy as np

def Tavg_C_attention(sentance,target_avg, x_mask):
    """
    Attention mechanism layer.
    :param inputs: outputs of RNN/Bi-RNN layer (not final state)
    :param attention_size: linear size of attention weights
    :return: outputs of the passed RNN/Bi-RNN reduced with attention vector
    """
    # In case of Bi-RNN input we need to concatenate outputs of its forward and backward parts

    hidden_size = sentance.get_shape()[2].value  # hidden size of the RNN layer
    print('--------------hidden_size.shape',hidden_size)#256---->2*128,2--->bidirectional_dynamic_rnn
    # Attention mechanism
    W_omega = tf.Variable(tf.truncated_normal([hidden_size, hidden_size], stddev=0.1),name="W_omega")#W必须是一个方阵
    b_omega = tf.Variable(tf.truncated_normal([hidden_size], stddev=0.1),name='b_omega')
    t_w=tf.matmul(target_avg,W_omega)
    print('-------------t_w.shape',t_w.shape)#[?,400]
    s_t_w=sentance*tf.expand_dims(t_w,1)
    print('-------------s_t_w.shape',s_t_w.shape)#[?,?,400]
    s_t_w=tf.reduce_sum(tf.tanh(s_t_w+b_omega),2)#按照第二维 hidden_size计算
    print('-------------s_t_w.shape',s_t_w.shape)
    alpha=tf.nn.softmax(s_t_w)#[?,?]
    print('-------------alpha.shape',alpha.shape)
    alpha=alpha*tf.cast(x_mask,'float')
    alpha=alpha/tf.expand_dims(tf.reduce_sum(alpha,1),1)
    print('---------------alpha.shape',alpha.shape)#[?,?]
    return alpha


def Cavg_T_attention(sentence_avg,target,t_mask):
	
	hidden_size = sentence_avg.get_shape()[1].value  # hidden size of the RNN layer
	print('--------------hidden_size.shape',hidden_size)#256---->2*128,2--->bidirectional_dynamic_rnn
	# Attention mechanism
	W_omega = tf.Variable(tf.truncated_normal([hidden_size, hidden_size], mean=0.0, stddev=0.1),name="W_omega")
	b_omega = tf.Variable(tf.truncated_normal([hidden_size], mean=0.0, stddev=0.1),name='b_omega')
	s_w=tf.matmul(sentence_avg,W_omega)
	print('---------------s_w.shape',s_w.shape)#[?,256]
	t_s_w=target*tf.expand_dims(s_w,1)
	print('---------------t_s_w.shape',t_s_w.shape)#[?,?,256]
	t_s_w=tf.reduce_sum(tf.tanh(t_s_w+b_omega),2)
	print('---------------t_s_w.shape',t_s_w.shape)#[?,?]
	alpha=tf.nn.softmax(t_s_w)
	print('---------------alpha.shape',alpha.shape)#[?,?]
	alpha=alpha*tf.cast(t_mask,'float')
	alpha=alpha/tf.expand_dims(tf.reduce_sum(alpha,1),1)
	print('---------------alpha.shape',alpha.shape)#[?,?]
	return alpha


class IAN(object):
	"""
	A CNN for text classification.
	Uses an embedding layer, followed by a convolutional, max-pooling and softmax layer.
	"""
	def __init__(self, args):

		rnn_sizes = args.rnn_sizes
		num_classes = args.num_classes
		emb_mat_unk = args.emb_mat_unk
		# VW = args.vocab_size
		# ES = args.embedding_size
		l2_reg_lambda = args.l2_reg_lambda

		# Placeholders for input, output and dropout
		self.input_x = tf.placeholder(tf.int32, [None, None], name="input_x")
		self.input_target = tf.placeholder(tf.int32,[None, None],name="input_target")
		self.target_mask=tf.placeholder('bool',[None, None],name="target_mask")
		self.x_mask = tf.placeholder('bool',[None,None],name="x_mask")
		self.input_y = tf.placeholder(tf.float32, [None, None], name="input_y")
		self.emb_mat = tf.placeholder(tf.float32, [None, None], name="emb_mat")
		self.dropout_keep_prob = tf.placeholder(tf.float32, name="dropout_keep_prob")

		# Keeping track of l2 regularization loss (optional)
		l2_loss = tf.constant(0.0)
		
		# Embedding layer 
		with tf.device('/cpu:0'), tf.variable_scope("embedding"):
			# self.emb_mat_unk = tf.Variable(emb_mat_unk, name="emb_mat_unk", dtype='float')
			self.emb_mat_unk = tf.get_variable("emb_mat_unk", dtype='float', initializer=args.emb_mat_unk)

			emb_mat = tf.concat([self.emb_mat_unk, self.emb_mat], axis=0)
			self.embedded_chars_x = tf.nn.embedding_lookup(emb_mat, self.input_x)#[batchsize, input_x],input_x=sequence_length*embeding_size
			self.embedded_chars_target = tf.nn.embedding_lookup(emb_mat,self.input_target)

		# RNN
		cell = tf.contrib.rnn.GRUCell(rnn_sizes)#the number of hidden units,return a list of variables
		cell_drop = tf.contrib.rnn.DropoutWrapper(cell, input_keep_prob=self.dropout_keep_prob)
		# # cell2
		cell2 = tf.contrib.rnn.GRUCell(rnn_sizes)
		cell2_drop = tf.contrib.rnn.DropoutWrapper(cell2,input_keep_prob=self.dropout_keep_prob)
		

		x_len = tf.reduce_sum(tf.cast(self.x_mask, 'int32'), 1)#1 表示按照行计算，把一行的数加起来，mask用于计算真实的句子长度(只计算true部分)
		t_len = tf.reduce_sum(tf.cast(self.target_mask, 'int32'), 1)
		
		
		#sequence_length=x_len 表示使用了mask sequence_length=None表示不使用mask
			
		with tf.variable_scope("rnn"):
			
			output_x, _ = tf.nn.bidirectional_dynamic_rnn(cell_fw=cell_drop, cell_bw=cell_drop, inputs=self.embedded_chars_x,sequence_length=x_len,dtype='float')
			print('----------------------output_x.shape----------------',output_x)#fw=[batchsize,?,128],bw=[batchsize,120,128]
			x = tf.concat(output_x, axis=2)
			print('----------------------------x.shape---------------',x.shape)#[batchsize,?,256],120--->the max sentance length, 256--->2*128
			x_pool=tf.reduce_mean(x,axis=1)

		with tf.variable_scope("rnn2"):
			output_target , _ = tf.nn.bidirectional_dynamic_rnn(cell_fw=cell2_drop,cell_bw=cell2_drop,inputs=self.embedded_chars_target,sequence_length=t_len,dtype='float')
			x_target=tf.concat(output_target,axis=2)
			x_target_pool=tf.reduce_mean(x_target,axis=1)
			# x = tf.reduce_mean(x, axis=1)#不加attention时的x
			# x_attention=attention(x2,attention_size,self.x_mask,l2_reg_lambda)
			# print('-------------add the attention:----------------',x_attention)
		Xavg_T_attention=Cavg_T_attention(sentence_avg=x_pool, target=x_target,  t_mask=self.target_mask)
		print('------------------x_Tavg_attention-----------',Xavg_T_attention.shape)
		#将得到的attention和句子的hidden表示相乘，得到最终的句子的表示
		tr=tf.reduce_sum(tf.multiply(x_target,tf.expand_dims(Xavg_T_attention,2)),1)
		Tavg_X_attention=Tavg_C_attention(sentance=x, target_avg=x_target_pool,  x_mask=self.x_mask)
		print('------------------T_xavr_attention-----------',Tavg_X_attention.shape)
		cr=tf.reduce_sum(tf.multiply(x,tf.expand_dims(Tavg_X_attention,2)),1)
		x_concat_t=tf.concat([tr,cr],axis=1)

		with tf.variable_scope("Softmax_layer_and_output"):
			softmax_w = tf.get_variable(name="softmax_w", shape=[4*rnn_sizes,num_classes], dtype='float')#4 是由于双向，因此节点个数是两倍，又由于是两个lstm拼接，因此4
			softmax_b = tf.get_variable(name="softmax_b", shape=[num_classes], dtype='float')
			self.logits = tf.nn.xw_plus_b(x_concat_t, softmax_w, softmax_b) 
			print("--------logits shape-------",self.logits.shape)

		# CalculateMean cross-entropy loss
		with tf.variable_scope("loss"):
			losses = tf.nn.softmax_cross_entropy_with_logits(logits=self.logits, labels=self.input_y)
			self.loss = tf.reduce_mean(losses)+l2_reg_lambda*tf.nn.l2_loss(softmax_w) 

		# pre 

		prediction = tf.argmax(self.logits,1)

		self.prediction = prediction

		# with tf.variable_scope("accuracy"):
		# 	self.prediction = tf.argmax(self.logits,1)
		# 	print('------prediction-------',self.prediction.shape)
		# 	correct_prediction = tf.equal(self.prediction, tf.argmax(self.input_y, 1))#the shape of self.input_y is 2
		# 	self.accuracy = tf.reduce_mean(tf.cast(correct_prediction, "float"), name="accuracy")


