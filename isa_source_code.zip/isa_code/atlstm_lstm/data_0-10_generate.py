#coding=utf-8
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LinearRegression
from sklearn import metrics
import numpy as np
import pandas as pd
import cPickle
from itertools import chain
# from sklearn imp or t svm
from collections import Counter


datas = cPickle.load(open("all_datas.p","r"))
labels = cPickle.load(open("all_label.p","r"))

# aspect=np.loadtxt('aspect.txt')
aspect = cPickle.load(open("aspect.p", "r"))
datas['aspect'] = aspect

for i in range(0,10):
	print i
	test = datas[datas['cv'] == i]
	train = datas[datas['cv'] != i]


	train_ast = list(chain(*zip(train['sentence'], train['aspect'],train['s_label'])))

	test_ast = list(chain(*zip(test['sentence'], test['aspect'],test['s_label'])))
	trainname = "train_%d.txt"%(i)
	testname = "test_%d.txt"%(i)

	ftr = open(trainname,'w')
	for i in train_ast:
		ftr.write(str(i)+'\n')
	ftr.close()

	fte = open(testname,'w')
	for i in test_ast:
		fte.write(str(i)+'\n')
	fte.close()
	