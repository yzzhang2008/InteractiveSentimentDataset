#-*- coding:utf-8 -*-

import os
import numpy as np
import tensorflow as tf
from collections import Counter
from tqdm import tqdm
# from sklearn import preprocessing
# import urllib

class DataSet(object):
    """docstring for DataSet"""
    def __init__(self, data, data_type):
        self.data = data
        self.data_type = data_type
        self.num_examples = len(self.data[0])
        self.in_s = None
        self.in_t = None
        self.in_y = None
    #把所有的词都变成id
    def vectorize(self, word_dict, word_dict_unk, sort_by_len=True, verbose=True):
        
        in_s, in_t, in_y = [], [], []
        
        for idx, (sent, targ, label) in enumerate(zip(self.data[0], self.data[1], self.data[2])):
            sent_words = sent.split(' ')
            targ_words = targ.split(' ')
            seq1, seq2 = [], []
            for w in sent_words:
                if w in word_dict_unk:
                    seq1.append(word_dict_unk[w])
                elif w in word_dict:
                    seq1.append(word_dict[w]+len(word_dict_unk))
                else:
                    seq1.append(1)

            for w in targ_words:
                if w in word_dict_unk:
                    seq2.append(word_dict_unk[w])
                elif w in word_dict:
                    seq2.append(word_dict[w]+len(word_dict_unk))
                else:
                    seq2.append(1)
            # seq1 = [word_dict[w] if w in word_dict else 1 for w in sent_words]#句子
            # seq2 = [word_dict[w] if w in word_dict else 1 for w in targ_words]#target

            if (len(seq1) > 0) and (len(seq2) > 0):
                in_s.append(seq1)
                in_t.append(seq2)
                in_y.append(int(label))
            if verbose and (idx % 1000 == 0):
                print('Vectorization: processed %d / %d' % (idx, self.num_examples))

        def len_argsort(seq):
            return sorted(range(len(seq)), key=lambda x: len(seq[x]), reverse=True)

        if sort_by_len:
            sorted_index = len_argsort(in_s)
            in_s = [in_s[i] for i in sorted_index]
            in_t = [in_t[i] for i in sorted_index]
            in_y = [in_y[i] for i in sorted_index]
        self.in_s = in_s
        self.in_t = in_t
        self.in_y = in_y

    def gen_minbatches(self, batch_size, emb_mat, start_examples=None, end_examples=None, shuffle=False):
        m = 0
        n = 0
        if start_examples is None:
            m = 0
            n = self.num_examples
        else:
            m = start_examples
            n = end_examples

        idx_list = np.arange(m, n, batch_size)
        if shuffle:
            np.random.shuffle(idx_list)
        minibatches = []
        for idx in idx_list:
            minibatches.append(np.arange(idx, min(idx + batch_size, n)))

        for minibatch in minibatches:
            mb_s = [self.in_s[t] for t in minibatch]
            mb_t = [self.in_t[t] for t in minibatch]
            mb_y = [self.in_y[t] for t in minibatch]
            mb_s, mb_s_mask = prepare_data(mb_s)#得到sentence的mask
            mb_t, mb_t_mask = prepare_data(mb_t)#得到target的mask
            mb_y = prepare_label(mb_y)#把label变成矩阵
            yield (mb_s, mb_t, mb_y, mb_s_mask, mb_t_mask, emb_mat)


def load_data(args, data_type=None, max_example=None):

    data_path_en = os.path.join(args.data_dir, "{}.txt".format(data_type))

    sentences = []
    targets = []
    labels = []

    num_examples = 0

    f1 = open(data_path_en, 'r', encoding='utf-8')
    while True:
        line = f1.readline()
        if not line:
            break
        sentence = line.strip().lower()
        target = f1.readline().strip().lower()
        label = f1.readline().strip()

        sentences.append(sentence)
        targets.append(target)
        labels.append(label)
        num_examples += 1

        if (max_example is not None) and (num_examples >= max_example):
            break
    f1.close()
    print('#Number examples: %d' % len(sentences))

    dataset = DataSet((sentences, targets, labels), data_type)
    return dataset
def build_dict_and_embeddings(sentences, dim, in_file=None):

    word_count = Counter()
    for sent in sentences:
        for w in sent.split():
            word_count[w] += 1

    word2vec_dict = {}
    pre_trained = 0
    if in_file is not None:
        with open(in_file, 'r', encoding='utf-8') as fh:
            for line in tqdm(fh, total=int(4e5)):
                array = line.lstrip().rstrip().split(" ")
                word = array[0]
                vector = list(map(float, array[1:]))
                if word in word_count:
                    word2vec_dict[word] = vector
                    pre_trained += 1
    print('Pre-trained: %d (%.2f%%)' %
        (pre_trained, pre_trained * 100.0 / len(word_count)))
    
    word_dict = {w: index for (index, w) in enumerate(w for w, count in word_count.items() if w in word2vec_dict)}
    word_dict_unk = {w: index + 2 for (index, w) in enumerate(w for w, count in word_count.items() if w not in word2vec_dict)}#  and count > 10
    word_dict_unk["NULL"] = 0
    word_dict_unk["UNK"] = 1
    
    idx2vec_dict = {idx: word2vec_dict[word] for word, idx in word_dict.items()}
        
    emb_mat = np.array([idx2vec_dict[idx] for idx in range(len(idx2vec_dict))], dtype='float32')
    emb_mat_unk = np.array([np.random.multivariate_normal(np.zeros(dim), np.eye(dim))
                        for idx in range(len(word_dict_unk))], dtype='float32')
    
    return word_dict, word_dict_unk, emb_mat, emb_mat_unk
#建立word2id的词典。{词：序号}
def build_dict(sentences, max_words=50000):

    word_count = Counter()
    for sent in sentences:
        for w in sent.split():
            word_count[w] += 1

    ls = word_count.most_common(max_words)

    print('#Words: %d -> %d' % (len(word_count), len(ls)))
    for key in ls[:5]:
        print(key)
    print('...')
    for key in ls[-5:]:
        print(key)

    # leave 0 to UNK
    # leave 1 to delimiter <s>
    # leave 2 to delimiter </s> 
    word_dict = {w[0]: index + 2 for (index, w) in enumerate(ls)}
    word_dict['NULL'] = 0
    word_dict['UNK'] = 1
    return word_dict
    # 查查most_common就知道为什么w[0]了.


#建立一个id2vector的矩阵，用于emdedding lookup
def gen_embeddings(word_dict, dim, in_file=None):
    """
        Generate an initial embedding matrix for `word_dict`.
        If an embedding file is not given or a word is not in the embedding file,
        a randomly initialized vector will be used.
        50000 * 100
        以词在词典中的序号为索引。
    """

    num_words = max(word_dict.values()) + 1
    embeddings = np.random.normal(0, 1, size=[num_words, dim])
    print('Embeddings: %d x %d' % (num_words, dim))

    if in_file is not None:
        print('Loading embedding file: %s' % in_file)
        pre_trained = 0
        for line in open(in_file, 'r', encoding='utf-8').readlines():
            sp = line.split()
            if len(sp) == 2:
                continue
            assert len(sp) == dim + 1
            if sp[0] in word_dict:#sp[0]是词，sp[1:]是向量
                pre_trained += 1
                embeddings[word_dict[sp[0]]] = [float(x) for x in sp[1:]]
        embeddings[word_dict['NULL']] = np.zeros(shape=[dim])
        print('Pre-trained: %d (%.2f%%)' %
                     (pre_trained, pre_trained * 100.0 / num_words))
    return embeddings


#将输入的text，target变成矩阵，同时生成相应的mask矩阵
def prepare_data(seqs):
    lengths = [len(seq) for seq in seqs]
    n_samples = len(seqs)
    max_len = np.max(lengths)
    x = np.zeros((n_samples, max_len)).astype('int32')
    x_mask = np.zeros((n_samples, max_len)).astype('float')
    for idx, seq in enumerate(seqs):
        x[idx, :lengths[idx]] = seq
        x_mask[idx, :lengths[idx]] = 1.0
    # print x, x_mask
    return x, x_mask

#将标签处理成onehot
def prepare_label(labels):
    # lb = preprocessing.LabelBinarizer()
    # onehot_labels = lb.fit_transform(labels)
    # return onehot_labels
    n_samples = len(labels)
    y_onehot = np.zeros((n_samples, 3)).astype('int32')
    for idx, label in enumerate(labels):
        if label == -1:
            y_onehot[idx, 0] = 1
        if label == 0:
            y_onehot[idx, 1] = 1
        if label == 1:
            y_onehot[idx, 2] = 1
    return y_onehot