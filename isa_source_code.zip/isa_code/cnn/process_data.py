#coding=utf-8
import os,re
import numpy as np
import pandas as pd
import cPickle as Pickle
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer, HashingVectorizer, CountVectorizer
from sklearn import metrics
from sklearn.svm import SVC
from os.path import join as Join

from util import load_bin_vec, Alphabet, add_to_vocab

def getData(cv=10):
	datas = []
	labels =[]
	files= os.listdir("dataset") #得到文件夹下的所有文件名称
	np.random.RandomState(23455)

		 
	for file in files: #遍历文件夹
		split = np.random.randint(0,cv)
		if not os.path.isdir(file):
			f = open("dataset"+"\\"+file,'r')				
			lines = f.readlines()
			for line in lines[0:-2]:
				nline=line.strip().lower()
				s_num,m,sen=nline.partition(":")
				sentence=sen[:-2].strip()
				

				sentence= re.sub(r"[, . ; \( \) \[ \] \' \"]", " ", sentence)
				sentence = re.sub(r"\?", " \? ", sentence)
				sentence=re.sub(r"\!", " \! ", sentence)
				sentence = re.sub(r"\s{2,}", " ", sentence)
				sentence =sentence.strip()


				s_label=sen[-2:].strip()
				data={'name':file,
				  'cv':split,
				  'sentence_num':s_num,
				  'sentence':sentence,
				  's_label': int(s_label),
				  }

				datas.append(data)



			a_label=lines[-1][:2].strip()
			b_label =lines[-1][-2:].strip()
			
			label={'name':file,
				  'cv':split,
				  'a_label': int(a_label),
				  'b_label': int(b_label),
				  }

			labels.append(label)
	return pd.DataFrame(datas), pd.DataFrame(labels)


if __name__ == '__main__':
	
	rng = np.random.RandomState(23455)
	datas, labels = getData(cv=10)
	datas['sentence'] = datas['sentence'].str.lower()
	Pickle.dump(datas, open("all_datas.p", "wb"))
	Pickle.dump(labels, open("all_label.p", "wb"))

	embeddings_file = Join('embeddings', 'aquaint+wiki.txt.gz.ndim=50.bin')#glove.6B.300d.txt
	know_dict = load_bin_vec(embeddings_file)
	ndim = len(know_dict[know_dict.keys()[0]])

	alphabet = Alphabet(start_feature_id=0)
	alphabet.add('UNKNOWN_WORD_IDX_0')


	add_to_vocab(datas['sentence'], alphabet)

	print alphabet.fid
	temp_vec = 0
	vocab_array = np.zeros((alphabet.fid, ndim), dtype = 'float32')
	for index in alphabet.keys():
		vec = know_dict.get(index, None)
		if vec is None:
			vec = rng.uniform(-0.25, 0.25, ndim)
			vec = list(vec)
			vec = np.array(vec, dtype = 'float32')
		if alphabet[index] == 0:
			vec = np.zeros(ndim)
		temp_vec += vec
		vocab_array[alphabet[index]] = vec
	temp_vec /= len(vocab_array)
	for index, _ in enumerate(vocab_array):
		vocab_array[index] -= temp_vec


	vocab_file = Join('interdata', 'vocab')
	alphabet_file = Join('interdata', 'alphabet')
	Pickle.dump(alphabet, open(alphabet_file, 'wb'))
	Pickle.dump(vocab_array, open(vocab_file, 'wb'))
	print alphabet.fid
	