两个文件夹
dataset文件夹下放的是原数据集
senti_based_process放的是用基于词典的方法，按照该文件夹下的redame文件，将其中生成的sentence_label_predicted.txt粘贴到sentiStrongth文件夹下

py文件
1.先运行process_data.py,生成两个pickle文件
2运行dic_add.py,生成直接加和的预测结果文件和pickle文件
3运行dic_lr.py,生成权重策略的预测结果文件