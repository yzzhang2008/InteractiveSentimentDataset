#-*- coding:utf-8 -*-

import tensorflow as tf

class Trainer(object):
    """docstring for Trainer"""
    def __init__(self, args, model):
        self.args = args
        self.model = model
        self.loss = model.loss
        self.opt = tf.train.MomentumOptimizer(args.init_lr,0.9)
        self.grads = self.opt.compute_gradients(self.loss)
        # clip_grads = [(tf.clip_by_value(grad, -5.0, 5.0), var) for grad, var in self.grads]
        self.train_op = self.opt.apply_gradients(self.grads)
        # self.summary = model.summary

    def get_train_op(self):
        return self.train_op

    def step(self, sess, batch, get_summary=False):
        assert isinstance(sess, tf.Session)
        feed_dict = {self.model.input_x : batch[0],
                     self.model.input_target : batch[1],
                     self.model.input_y : batch[2],
                     self.model.x_mask : batch[3],
                     self.model.target_mask : batch[4],
                     self.model.emb_mat: batch[5],
                     self.model.dropout_keep_prob : 0.8}
        loss, train_op = sess.run([self.loss, self.train_op], feed_dict=feed_dict)
        return loss, train_op


