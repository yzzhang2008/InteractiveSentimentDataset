 # -*- coding:utf-8 -*- 
import numpy as np
import tensorflow as tf

import math
import os
import sys
import time
import data_helper
from model import IAN
from trainer import Trainer
from evaluator import Evaluator

def main(args):
    ccv = 0
    # for ccv in range(4,10):
    with tf.device("/gpu:0"):
        print('Load data files...')

        print('*' * 10 + ' Train')
        # train_data = data_helper.load_data(args, 'train', 20000)
        trainname='train_'+str(ccv)
        # train_data = data_helper.load_data(args, 'train_3')
        train_data = data_helper.load_data(args, trainname)
        # print(train_data.data[2])
        # exit()
        print('*' * 10 + ' Test')
        # test_data = data_helper.load_data(args, 'test')
        testname='test_'+str(ccv)
        # test_data = data_helper.load_data(args, 'test_3')
        test_data = data_helper.load_data(args, testname)
        # print('sentence:',test_data.data[0])
        # print('target:',test_data.data[1])
        # print('label:',test_data.data[2])
        # exit()
        print('-' * 50)
        print('Build dictionary..')

        args.word_dict, args.word_dict_unk, args.emb_mat, args.emb_mat_unk = data_helper.build_dict_and_embeddings(train_data.data[0] + test_data.data[0] + train_data.data[1] + test_data.data[1], args.embedding_dim, args.glove_file)


        print('-' * 50)
        # #生成id2vec的embedding词表矩阵
        # args.embeddings = data_helper.gen_embeddings(args.word_dict, args.embedding_dim, args.glove_file)

        (args.vocab_size, args.embedding_size) = args.emb_mat_unk.shape


        train_data.vectorize(args.word_dict, args.word_dict_unk)
        test_data.vectorize(args.word_dict, args.word_dict_unk, sort_by_len=False)
        
        model = IAN(args)
        trainer = Trainer(args, model)
        evaluator = Evaluator(args, model)

        timestamp = str(int(time.time()))
        out_dir = os.path.join(args.out_dir, timestamp)
        checkpoint_dir = os.path.join(out_dir, "checkpoints")
        checkpoint_prefix = os.path.join(checkpoint_dir, "model")
        if not os.path.exists(checkpoint_dir):
            os.makedirs(checkpoint_dir)        
        saver = tf.train.Saver(tf.global_variables())
        
        config_gpu = tf.ConfigProto(allow_soft_placement=True, log_device_placement=False)
        config_gpu.gpu_options.allow_growth = True
        sess = tf.Session(config=config_gpu)
        sess.run(tf.global_variables_initializer())
        if args.load:
            cpkl = os.path.join(args.out_dir,"1517401853/checkpoints/model-3392")
            saver.restore(sess, save_path=cpkl)
            test_acc, pre_list = evaluator.get_evaluation(sess, test_data.gen_minbatches(args.batch_size, args.emb_mat))
            print('Test accuracy: %.4f ' % test_acc)
            np.savetxt(str(test_acc)+"pre_list_3.txt",pre_list,fmt='%s',newline='\n')

            return 
            # return

        

        # Training
        print('-' * 50)
        print('Start training..')
        start_time = time.time()
        last_time = start_time        
        n_updates = 0
        batch100_time = 0
        test_acc = 0
        best_acc = test_acc
        dev_list=[]
        fname = str(ccv)+'_predic_info.txt'
        f = open(fname,'w+')
        for epoch in range(args.num_epoches):
            test_prelist=[]
            for idx, batch in enumerate(train_data.gen_minbatches(args.batch_size, args.emb_mat, shuffle=False)):
                # print(batch[2])
                # exit()
                train_loss, train_op = trainer.step(sess, batch)
                batch_time = time.time() - last_time
                # if idx % 20 == 0:
                print('Epoch = %d, iter = %d, loss = %.4f, batch time = %.4f (s)' %
                         (epoch, idx, train_loss, batch_time))
                n_updates += 1
                batch100_time = batch100_time + batch_time
                # Evalution
                if n_updates % args.eval_iter == 0 or best_acc > 0.76:
                    start_examples = np.random.randint(0, train_data.num_examples - test_data.num_examples)
                    end_examples = start_examples + test_data.num_examples
                    train_acc = evaluator.get_evaluation(sess, train_data.gen_minbatches(args.batch_size, args.emb_mat, start_examples, end_examples))
                    # print('Epoch = %d, iter = %d, train_acc = %.4f' % (epoch, idx, train_acc))

                    test_acc, test_prelist = evaluator.get_evaluation(sess, test_data.gen_minbatches(args.batch_size, args.emb_mat))
                    dev_list.append(test_acc)

                    # print ("idx", idx)
                    test_prelist.append(test_prelist)
                    print('Epoch = %d, iter = %d, test_acc = %.4f' % (epoch, idx, test_acc))

                    if test_acc > best_acc:
                        best_acc = test_acc
                        print('Best test acc: epoch = %d, n_udpates = %d, acc = %f ' % (epoch, n_updates, test_acc))
                        path = saver.save(sess, checkpoint_prefix, global_step=n_updates)
                        print("Saved model checkpoint to {}\n".format(path))
                        filename = "epoch_" + str(epoch)+"_test_pre_list_"+str(ccv)+".txt"
                        np.savetxt(filename,test_prelist,fmt='%s',newline='\n')
                        
                        f.write('Epoch = %d, iter = %d, test_acc = %.4f, \n' % (epoch, idx, test_acc))
                        f.write("Saved model checkpoint to {}\n".format(path))

                        
                last_time = time.time()
            # filename = str(epoch)+
            # np.savetxt("epoch_" + str(epoch)+"_test_pre_list.txt",test_prelist,fmt='%s',newline='\n')
        # np.savetxt("dev_list.txt",dev_list,fmt='%s',newline='\n')
        f.close()
        print('---------the max Evaluation------',np.max(dev_list))
