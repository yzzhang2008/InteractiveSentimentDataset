step1：准备好一个平滑文本，每行为一个句子的多行文本文件（第一行为空行）
此处，我们采用content.txt文件(所有对话的单个句子组成)
【我们这里可由下面代码生成
datas = cPickle.load(open("all_datas.p","r"))
np.savetxt("content.txt",datas['sentence'],fmt='%s',newline='\n')】

step2：运行SentiStrength2.3Free.exe,选择相应选项，
最后生成包含每个句子的pos值和neg值（1-5）的content+results.txt文件

step3：运行sentidic_preditedlist.py
注意其中文件的所在目录位置，生成包含每个句子的基于词典的预测标签值的sentence_label_predicted.txt