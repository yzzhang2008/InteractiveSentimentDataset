import numpy as np 
import pandas as pd 
import cPickle as Pickle
from PIL import Image
import os, sys,re
from sklearn.utils import shuffle
import theano
import theano.tensor as T


class Alphabet(dict):
  def __init__(self, start_feature_id=1):
    self.fid = start_feature_id

  def add(self, item):
    idx = self.get(item, None)
    if idx is None:
      idx = self.fid
      self[item] = idx
      # self[idx] = item 
      self.fid += 1
    return idx

  def dump(self, fname):
    with open(fname, "w") as out:
      for k in sorted(self.keys()):
        out.write("{}\t{}\n".format(k, self[k]))



def add_to_vocab(data, alphabet):
	for sentence in data:
		sentence = re.sub('the', ' ',sentence)
		for token in sentence.split():
			alphabet.add(token)


def sentence_index(sen, alphabet, input_lens):
	sen = sen.split()
	sen_index = []
	for word in sen:
		sen_index.append(alphabet[word])
	sen_index = sen_index[:input_lens]
	while len(sen_index) < input_lens:
		sen_index += sen_index[:(input_lens - len(sen_index))]

	return np.array(sen_index), len(sen)


def sentence_indece(crous, input_lens, alphabet):
	sens = crous['sentence']
	labels = crous['s_label']
	sen_indece = []
	for sen in sens:
		sen_index, sen_len = sentence_index(sen, alphabet, input_lens)
		sen_indece.append(sen_index)
	
	labels_list = []
	for i in list(labels):
		labels_list.append(i+1)
	return sen_indece, labels_list


def batch_pad(dataset, batchsize):
	batch_num = int(len(dataset) / batchsize)
	extra_num = len(dataset) - batch_num * batchsize
	if extra_num > 0:
		pad_num = batchsize - extra_num
		dataset += dataset[:pad_num]
		
def batch_num(dataset, batchsize):
	batchs = int(len(dataset) / batchsize)
	extra_num = len(dataset) - batchs * batchsize
	if extra_num > 0:
		return batchs + 1
	else:
		return batchs


def load_bin_vec(fname):
	
	print fname
	word_vecs = {}
	with open(fname, "rb") as f:
		header = f.readline()
		vocab_size, layer1_size = map(int, header.split())
		binary_len = np.dtype('float32').itemsize * layer1_size
		print 'vocab_size, layer1_size', vocab_size, layer1_size
		for i, line in enumerate(xrange(vocab_size)):
			if i % 100000 == 0:
				print '.',
			word = []
			while True:
				ch = f.read(1)
				if ch == ' ':
					word = ''.join(word)
					break
				if ch != '\n':
					word.append(ch)
			word_vecs[word] = np.fromstring(f.read(binary_len), dtype='float32')
		print "done"
		return word_vecs





def share_x(data_x, batchsize):
	batch_pad(data_x, batchsize)
	return theano.shared(np.asarray(data_x, dtype=theano.config.floatX), borrow = True)

def share_y(data_x, batchsize):
	batch_pad(data_x, batchsize)
	return T.cast(theano.shared(np.asarray(data_x), borrow = True), 'int32')

def share_m(data_x, batchsize):
	batch_pad(data_x, batchsize)
	# return T.cast(theano.shared(np.asarray(data_x), borrow = True), 'int32')
	return theano.shared(np.asarray(data_x, dtype=theano.config.floatX), borrow = True)