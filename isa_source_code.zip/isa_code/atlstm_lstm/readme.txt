三个个文件夹
code里面是lstm和atlstm句子分类的代码
embedings文件夹放的是词向量文件，wiki50
dataset文件夹下放的是原数据集

content.txt是原来的数据集按行读入写的文件

py文件
1.先运行process_data.py,生成两个pickle文件
2.运行at_lstm_process_data.py,生成word_id.txt和isa_word_emdedding.txt，将其放入code/data/isa文件夹中
3.运行data_0-10_generate.py,生成10折的数据集，并将生成的文件剪切到code/data/isa文件夹下
3.运行aspect_generate.py,生成aspect.txt的文件
4.运行add_label.py,生成aspect_id.txt的文件,并将生成的文件剪切到code/data/isa文件夹下
5.打开code文件，运行atlstm或者lstm.py,(修改用的训练集、测试集名字),并将每折最后生成的文件剪切到atlstm_lstm文件夹下
6运行lstm_add_result.py,生成直接加和的预测结果文件
7运行lstm_lr_result.py,生成权重策略的预测结果文件
6运行atlstm_add_result.py,生成直接加和的预测结果文件
7运行atlstm_lr_result.py,生成权重策略的预测结果文件