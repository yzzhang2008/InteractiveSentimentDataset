#coding=utf-8
import re
import pandas as pd
import numpy as np
f = open('C:\\Users\\Ling\\Desktop\\interactdataset\\experiment_SA\\svm\\dic-based\\SentiStrength\\content+results.txt')
i = 0
pre_label=[]
for line in f.readlines():
	line = line.strip()
	# line = line.split()
	# print line
	totalCount = re.sub("\D", "", line)
	# print totalCount
	final= int(totalCount[0]) - int(totalCount[1])
	# print pos,neg
	# final = pos - neg
	# print i
	if final > 0:
		pre_label.append(1)
	elif final < 0:
		pre_label.append(-1)
	else:
		pre_label.append(0)
	
	i += 1

print pre_label
print len(pre_label)

np.savetxt("sentence_label_predicted.txt", pre_label, fmt='%s',newline='\n')