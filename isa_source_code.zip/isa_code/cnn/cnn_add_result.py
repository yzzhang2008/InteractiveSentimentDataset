#coding=utf-8
import pandas as pd
import numpy as np
import cPickle
from sklearn import metrics
from collections import Counter

datas = cPickle.load(open("all_datas.p","r"))
labels = cPickle.load(open("all_label.p","r"))

a_acc_list=[]
a_prf_list=[]
b_acc_list=[]
b_prf_list=[]
fwname='result_cnn_add_final.txt'
fw=open(fwname,'w+')
# ccv=1

for ccv in range(0,10):
	# fwname='result_cnn_add_data'+str(ccv)+'.txt'
	# fw=open(fwname,'w+')
	fw.write('add:cnn_data'+str(ccv)+'\n\n')
	print 'add:cnn_data',ccv

	
	test = datas[datas['cv'] == ccv]
	train = datas[datas['cv'] != ccv]
	test_label = labels[labels['cv']==ccv]
	

	sen_count= Counter(test['name'])#
	# print sen_count
	items = sen_count.items() 
	items.sort() 
	# print items
	test_list = [key for key, value  in items]#test集中文件名
	sen_count_list =[value  for key, value  in items]

	ssen_list=[]
	
	prename = "cnn_predicted_data" +str(ccv)+".txt"
	predicted = np.loadtxt(prename)
	

	begin = 0
	end=0
	for i in sen_count_list:
		begin =end
		end = begin+i
		ssen_list.append(list(predicted[begin:end]))

	a_sum =[]
	b_sum =[]
	for j in ssen_list:
		a_sum.append(sum(j[0::2]))
		b_sum.append(sum(j[1::2]))
	
	a_new=[]
	b_new=[]
	for i in a_sum:
		if i > 0:
			a_new.append(1)
		elif i < 0:
			a_new.append(-1)
		else:
			a_new.append(0)
	# print a_new

	for i in b_sum:
		if i > 0:
			b_new.append(1)
		elif i < 0:
			b_new.append(-1)
		else:
			b_new.append(0)
	
	prfa =  metrics.classification_report(test_label['a_label'], a_new)
	cma = metrics.confusion_matrix(test_label['a_label'], a_new)
	acca =metrics.accuracy_score(test_label['a_label'], a_new)

	prfb =  metrics.classification_report(test_label['b_label'], b_new)
	cmb = metrics.confusion_matrix(test_label['b_label'], b_new)
	accb =metrics.accuracy_score(test_label['b_label'], b_new)

	# print type(cma)

		
	print "A的结果"
	print prfa
	print '\n'
	print '混淆矩阵'
	print cma
	print '\n'
	print 'acc：'
	print acca

	print '\n'

	print "B的结果"
	print prfb
	print '\n'
	print '混淆矩阵'
	print cmb
	print '\n'
	print 'acc：'
	print accb



	fw.write('\n A的结果 \n')
	fw.write(prfa)
	fw.write('\n 混淆矩阵\n')
	for i in cma:	
		fw.write(str(i)+"\n")
	fw.write('\n acc：')
	fw.write(str(acca))
	fw.write('\n')
	fw.write('\n B的结果 \n')
	fw.write(prfb)
	fw.write('\n 混淆矩阵 \n')
	for i in cmb:	
		fw.write(str(i)+"\n")
	fw.write('\n acc：')
	fw.write(str(accb))
	fw.write('\n')
	# fw.close()

	prfa_list = prfa.encode('utf-8').split()
	prfb_list = prfa.encode('utf-8').split()
	a_para=[]
	
	for i in prfa_list[5:8]:
		a_para.append(float(i))#-1类的指标
	for j in prfa_list[10:13]:
		a_para.append(float(j))#0类的指标
	for k in prfa_list[15:18]:
		a_para.append(float(k))#1类的指标
	for l in prfa_list[22:25]:
		a_para.append(float(l))#avg类的指标
	b_para=[]
	for i in prfb_list[5:8]:
		b_para.append(float(i))#-1类的指标
	for j in prfb_list[10:13]:
		b_para.append(float(j))#0类的指标
	for k in prfb_list[15:18]:
		b_para.append(float(k))#1类的指标
	for l in prfb_list[22:25]:
		b_para.append(float(l))#avg类的指标

	a_acc_list.append(acca)
	a_prf_list.append(a_para)
	b_acc_list.append(accb)
	b_prf_list.append(b_para)



avgprfa = np.array(a_prf_list).mean(axis=0)
avgprfb = np.array(b_prf_list).mean(axis=0)
avgacca = np.array(a_acc_list).mean()
avgaccb = np.array(b_acc_list).mean()
# aaa = avgprfa.reshape(4,3)

print 'a的p,r,f',avgprfa.reshape(4,3)
print 'b的p,r,f',avgprfb.reshape(4,3)
print 'a的平均acc',avgacca
print 'b的平均acc',avgaccb


row_name=['class','presion','recall','f1']
colum_name =[str(-1),str(0),str(1),'avg/total']
fw.write('\n \n\n a的综合结果 \n')

for i in row_name:
	fw.write(i)
	fw.write('		')
fw.write('\n \n')

for i,j in zip(colum_name,avgprfa.reshape(4,3)):
	fw.write(i)
	fw.write('		')
	for k in j:
		fw.write(str(k))
		fw.write('		')
	fw.write('\n \n')
fw.write('\n avg_acc: ')
fw.write(str(avgacca))

fw.write('\n \n\n b的综合结果 \n')

for i in row_name:
	fw.write(i)
	fw.write('		')
fw.write('\n \n')

for i,j in zip(colum_name,avgprfb.reshape(4,3)):
	fw.write(i)
	fw.write('		')
	for k in j:
		fw.write(str(k))
		fw.write('		')
	fw.write('\n \n')
fw.write('\n avg_acc: ')
fw.write(str(avgaccb))

fw.write('\n')
fw.close()
