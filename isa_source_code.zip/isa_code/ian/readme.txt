四个文件夹
code里面是ian句子分类的代码
data文件夹放的是词向量文件glove.6B.300d.txt和10折经过处理的数据集
out文件夹放的是ian生成的model文件
dataset文件夹下放的是原数据集

content.txt是原来的数据集按行读入写的文件

六个py文件
1.先运行process_data.py,生成两个pickle文件
2.运行aspect_generate_IAN.py,生成aspect的文件
3.运行data_0-10_generate_IAN.py,生成10折的数据集，并将生成的文件剪切到data文件夹下
4.打开code文件，运行run.py,(main函数中ccv=0，(0-9)代表的是运行的哪折数据),每折最后生成的文件统一命名为
epoch_9_test_pre_list_i.txt，其中i=(0-9)，将10个文件剪切到ian文件夹下
5运行IAN_process_ori_prelist.py
6运行IAN_add_result.py,生成直接加和的预测结果文件
7运行IAN_lr_result.py,生成权重策略的预测结果文件