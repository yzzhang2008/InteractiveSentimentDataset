一个文件夹
dataset文件夹下放的是原数据集

py文件
1.先运行process_data.py,生成两个pickle文件
2运行svm_add.py,生成直接加和的预测结果文件和pickle文件
3运行svm_lr.py,生成权重策略的预测结果文件